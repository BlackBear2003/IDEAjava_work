package TestWork02;

public class CatNotFoundException extends BaseException{
    public CatNotFoundException(String message){
        super(message);
    }
}
