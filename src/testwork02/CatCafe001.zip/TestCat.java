package TestWork02;

import java.time.LocalDate;

public class TestCat {

    public static void main(String[] args) {

        MyCatCafe myCatCafe = new MyCatCafe();
        myCatCafe.setLd(LocalDate.of(2021, 11, 16));
        myCatCafe.setMoney(200);
        Customer wzl = new Customer("wzl", 3, myCatCafe.getLd());

        try {
            myCatCafe.BuyNewOrangeCat("001", "boy", 3, true);
            myCatCafe.BuyNewBlackCat("002", "boy", 3);
            //myCatCafe.BuyNewBlackCat("003","boy",3);

            myCatCafe.ServeCustomer(wzl);
            myCatCafe.CloseCafe();
        } catch (CatNotFoundException e) {
            System.out.println("Failed to serve the customer ");
            e.printStackTrace();
        } catch (InsufficientBalanceException e) {
            System.out.println("Failed to purchase!");
            e.printStackTrace();
        }

    }
}
