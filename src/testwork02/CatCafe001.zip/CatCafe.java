package TestWork02;

public interface CatCafe {
    void BuyNewOrangeCat(String name,String gender,int age,boolean IsFat);
    void BuyNewBlackCat(String name ,String gender ,int age);
    void ServeCustomer(Customer customer);
    void CloseCafe();
}
