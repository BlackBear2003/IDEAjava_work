package TestWork02;

import java.time.LocalDate;

public class Customer {
    private String name;
    private int RuaTime;
    private LocalDate localDate;

    public Customer(String name, int ruaTime, LocalDate localDate) {
        this.name = name;
        RuaTime = ruaTime;
        this.localDate = localDate;
    }

    @Override
    public String toString(){
        return "A customer named " + getName() + ".\n"+getName()+" wants to rua the cat for "+getRuaTime()+" times.\n"
                + getName() + " arrives at "+getLocalDate()+".\n";
    }

    public int getRuaTime() {
        return RuaTime;
    }

    public void setRuaTime(int ruaTime) {
        RuaTime = ruaTime;
    }

    public LocalDate getLocalDate() {
        return localDate;
    }

    public void setLocalDate(LocalDate localDate) {
        this.localDate = localDate;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
