package testwork02;

public enum Gender {
    Male,Female,HalfMale//你懂的
}
