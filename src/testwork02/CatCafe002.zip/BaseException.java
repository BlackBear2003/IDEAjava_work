package testwork02;

public class BaseException extends RuntimeException {

    public BaseException(String message) {
        super(message);
    }

}
