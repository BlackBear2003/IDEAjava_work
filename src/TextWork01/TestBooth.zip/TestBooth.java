package TextWork01;

import java.util.Scanner;

public class TestBooth {


    public static void main(String[] args) {

        Booth zhengtao = new Booth(114514111, "郑涛", 80, true);

        Booth huaqiang = new Booth(348358584, "华强", 80, false);

        huaqiang.setId(233333333);
        huaqiang.setName("强子");
        System.out.println(huaqiang);
        System.out.println(zhengtao);

        Booth.purchase(huaqiang, huaqiang.getTotal());
        huaqiang.restock(100);

        Booth[] booths = {zhengtao, huaqiang};
        Booth.closeBooths(booths);

        System.out.println("下面是输入一个商贩的方法");
        inputBooth();
        System.out.println("test");
        inputBooth();
    }
    public static void inputBooth() {
        Scanner input = new Scanner(System.in);
        System.out.println("下面开始创建一个西瓜摊\n请输入ID");
        long testid = input.nextLong();
        long id = 0;
        boolean flag = true;
        //判断ID的重复性
        while (flag){
            for (long i:
                    Booth.IDlist) {
                if(i == testid){
                    System.out.println("ID重复！请重新输入");
                    testid = input.nextLong();
                    break;
                }
                else {
                    System.out.println("ID输入成功！");
                    flag = false;
                    id = testid;
                    break;
                }
            }
        }

        System.out.println("请输入摊主的名字");
        String name = input.next();

        System.out.println("请输入西瓜摊上西瓜的数量");
        int total = input.nextInt();

        System.out.println("请输入西瓜摊是否整改的");
        boolean isClosed = input.nextBoolean();

        Booth newbooth = new Booth(id,name,total,isClosed);

        System.out.println(newbooth);
    }

    }
